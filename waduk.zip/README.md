### One repository to rule them all
Add all other repositories at once. Add this repository using this shortcode: [id45](https://self-similarity.github.io/http-protocol-redirector?r=cloudstreamrepo://raw.githubusercontent.com/enyny/MegaRepo/master/repo.json)

~Click~ Pet the gorilla to install it on your phone:

[<img alt="alt_text" width="100px" src="https://discord.com/assets/e8b3b5a31c0a3c541960bd3ddccc538f.svg"/>](https://self-similarity.github.io/http-protocol-redirector?r=cloudstreamrepo://raw.githubusercontent.com/enyny/MegaRepo/master/repo.json)
